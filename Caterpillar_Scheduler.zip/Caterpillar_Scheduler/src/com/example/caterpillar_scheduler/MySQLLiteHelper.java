package com.example.caterpillar_scheduler;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class MySQLLiteHelper extends SQLiteOpenHelper {

  public static final String TABLE_LISTS = "lists";
  public static final String LIST_ID = "_id";
  public static final String LIST_NAME = "name";
  
  public static final String TABLE_TASKS = "tasks";
  public static final String TASK_ID = "_id";
  public static final String TASK_NAME = "name";
  public static final String TASK_ISCHECKED = "isChecked";
  public static final String TASK_LISTID = "ListID";

  private static final String DATABASE_NAME = "caterpillardb.db";
  private static final int DATABASE_VERSION = 9;

  // Database creation sql statement
  private static final String CREATE_LISTS = "create table "
      + TABLE_LISTS + "(" + LIST_ID
      + " integer primary key autoincrement, " + LIST_NAME
      + " text not null);";
  
  private static final String CREATE_TASKS = "create table " + TABLE_TASKS + "(" + TASK_ID
      + " integer primary key autoincrement, " + TASK_NAME
      + " text not null, " + TASK_ISCHECKED + " integer, " + TASK_LISTID +
      " integer, foreign key(" + TASK_LISTID +") references " + TABLE_LISTS +
      " (" + LIST_ID +"));";
  
  

  public MySQLLiteHelper(Context context) {
    super(context, DATABASE_NAME, null, DATABASE_VERSION);
  }

  @Override
  public void onCreate(SQLiteDatabase database) {
    database.execSQL(CREATE_LISTS);
    database.execSQL(CREATE_TASKS);
  }

  @Override
  public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    Log.w(MySQLLiteHelper.class.getName(),
        "Upgrading database from version " + oldVersion + " to "
            + newVersion + ", which will destroy all old data");
    db.execSQL("DROP TABLE IF EXISTS " + TABLE_TASKS);
    db.execSQL("DROP TABLE IF EXISTS " + TABLE_LISTS);
    onCreate(db);
  }

} 