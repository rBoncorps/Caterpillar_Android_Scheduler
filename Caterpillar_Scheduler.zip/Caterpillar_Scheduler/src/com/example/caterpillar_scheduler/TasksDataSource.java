package com.example.caterpillar_scheduler;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class TasksDataSource {

  // Database fields
  private SQLiteDatabase database;
  private MySQLLiteHelper dbHelper;
  private String[] allColumns = { MySQLLiteHelper.TASK_ID,
      MySQLLiteHelper.TASK_NAME,
      MySQLLiteHelper.TASK_ISCHECKED,
      MySQLLiteHelper.TASK_LISTID};

  public TasksDataSource(Context context) {
    dbHelper = new MySQLLiteHelper(context);
  }

  public void open() throws SQLException {
    database = dbHelper.getWritableDatabase();
  }

  public void close() {
    dbHelper.close();
  }

  public Task createTask(String taskName,long isChecked,long parentListID) {
    ContentValues values = new ContentValues();
    values.put(MySQLLiteHelper.TASK_NAME, taskName);
    values.put(MySQLLiteHelper.TASK_ISCHECKED, isChecked);
    values.put(MySQLLiteHelper.TASK_LISTID, parentListID);
    long insertId = database.insert(MySQLLiteHelper.TABLE_TASKS, null,
        values);
    Cursor cursor = database.query(MySQLLiteHelper.TABLE_TASKS,
        allColumns, MySQLLiteHelper.TASK_ID + " = " + insertId, null,
        null, null, null);
    cursor.moveToFirst();
    Task newTask = cursorToTask(cursor);
    cursor.close();
    return newTask;
  }

  public void deleteTask(Task task) {
    long id = task.getId();
    System.out.println("Comment deleted with id: " + id);
    database.delete(MySQLLiteHelper.TABLE_TASKS, MySQLLiteHelper.TASK_ID
        + " = " + id, null);
  }
  
  public void renameTask(Task task, String newName) {
	  ContentValues args = new ContentValues();
	  args.put(MySQLLiteHelper.TASK_NAME, newName);
	  long id = task.getId();
	  database.update(MySQLLiteHelper.TABLE_TASKS, args, MySQLLiteHelper.TASK_ID
		        + " = " + id,null);
  }
  
  public void setCheckStateTask(Task task,long isChecked) {
	  ContentValues args = new ContentValues();
	  args.put(MySQLLiteHelper.TASK_ISCHECKED, isChecked);
	  long id = task.getId();
	  database.update(MySQLLiteHelper.TABLE_TASKS, args, MySQLLiteHelper.TASK_ID
		        + " = " + id,null);
  }

  public List<Task> getAllTasks() {
	    List<Task> tasks = new ArrayList<Task>();

	    Cursor cursor = database.query(MySQLLiteHelper.TABLE_TASKS,
	        allColumns,null, null, null, null, null);

	    cursor.moveToFirst();
	    while (!cursor.isAfterLast()) {
	      Task task = cursorToTask(cursor);
	      tasks.add(task);
	      cursor.moveToNext();
	    }
	    // Make sure to close the cursor
	    cursor.close();
	    return tasks;
  }
  
  public List<Task> getAllTasks(long listID) {
    List<Task> tasks = new ArrayList<Task>();
    List<Task> checkedTasks = new ArrayList<Task>();

    Cursor cursor = database.query(MySQLLiteHelper.TABLE_TASKS,
        allColumns, MySQLLiteHelper.TASK_LISTID + " = " + listID, null, null, null, null);

    cursor.moveToFirst();
    while (!cursor.isAfterLast()) {
      Task task = cursorToTask(cursor);
      if(task.isChecked()) {
    	  checkedTasks.add(task);
      }
      else {
    	  tasks.add(task);
      }
      cursor.moveToNext();
    }
    // Make sure to close the cursor
    cursor.close();
    tasks.addAll(checkedTasks);
    return tasks;
  }

  private Task cursorToTask(Cursor cursor) {
    Task task = new Task();
    task.setId(cursor.getLong(0));
    task.setName(cursor.getString(1));
    task.setChecked(cursor.getLong(2));
    task.setTaskListID(cursor.getLong(3));
    return task;
  }
} 