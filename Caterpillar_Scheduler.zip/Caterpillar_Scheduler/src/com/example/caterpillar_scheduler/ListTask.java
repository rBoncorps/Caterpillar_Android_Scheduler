package com.example.caterpillar_scheduler;

import java.util.ArrayList;
import java.util.List;

import com.example.caterpillar_scheduler.Task;

public class ListTask {

	public long listID;
	public String listName;
	
	/*public ListTask(String newListName) {
		//listID = Integer.toString(id);
		listName = newListName;
	}*/
	
	public long getId() {
	    return listID;
	  }

	  public void setId(long id) {
	    this.listID = id;
	  }

	  public String getName() {
	    return listName;
	  }

	  public void setName(String newName) {
	    this.listName = newName;
	  }

	  // Will be used by the ArrayAdapter in the ListView
	  @Override
	  public String toString() {
	    return listName;
	  }
	
	
}
