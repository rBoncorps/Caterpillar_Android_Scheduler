package com.example.caterpillar_scheduler;

import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

/**
 * An activity representing a list of Domain. This activity has different
 * presentations for handset and tablet-size devices. On handsets, the activity
 * presents a list of items, which when touched, lead to a
 * {@link TaskDetailActivity} representing item details. On tablets, the
 * activity presents the list of items and item details side-by-side using two
 * vertical panes.
 * <p>
 * The activity makes heavy use of fragments. The list of items is a
 * {@link TaskListFragment} and the item details (if present) is a
 * {@link TaskDetailFragment}.
 * <p>
 * This activity also implements the required {@link TaskListFragment.Callbacks}
 * interface to listen for item selections.
 */
public class TaskListActivity extends Activity {
	public ListsDataSource listsdatasource;
	public List<ListTask> listListTasks;
	public ListTaskAdapter adapter;


	public static int contextList;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_task_list);
		
		listsdatasource = new ListsDataSource(this);
		listsdatasource.open();
		
		listListTasks = listsdatasource.getAllLists();
		adapter = new ListTaskAdapter(this,R.layout.listaskview,listListTasks);
		
		ListView list = (ListView)findViewById(R.id.task_list_m);
		list.setAdapter(adapter);
		
		list.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> adap, View v, int position,
					long id) {
				ListTask list = (ListTask)adap.getItemAtPosition(position);
				Intent detailIntent = new Intent(getApplicationContext(), TaskDetailActivity.class);
				detailIntent.putExtra(TaskDetailActivity.LIST_ID,list.getId());
				detailIntent.putExtra(TaskDetailActivity.LIST_NAME, list.getName());
				startActivity(detailIntent);
			}
		});
		
		final EditText edittext = (EditText) findViewById(R.id.NewListTextEdit);
		edittext.setOnEditorActionListener(new TextView.OnEditorActionListener() {
	        @Override
	        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
	            if (actionId == EditorInfo.IME_ACTION_DONE) {
	            	
	            	addNewList(v.getText().toString());
	            	v.setText("");
	            }
	            return false;
	        }
	    });
		registerForContextMenu(findViewById(R.id.task_list_m));
		//findViewById(R.id.task_list_frag).requestFocus();
		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.mainmenu, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem menuItem) {
		switch(menuItem.getItemId()) {
			case R.id.action_deleteAll:
				List<ListTask> l = listsdatasource.getAllDone();
				if(!l.isEmpty()){
					for(int i = 0; i<l.size() ; i++) {
						deleteList(l.get(i));
					}
					return true;
				}
		}
		return false;
	}

	
	public void addNewList(String name) {	
		ListTask list = listsdatasource.createListTask(name);
		adapter.add(list);
		adapter.notifyDataSetChanged();
	}
	
	public void deleteList(int position) {
		ListTask listTask = adapter.getItem(position);
		listsdatasource.deleteListTask(listTask);
		adapter.remove(listTask);
	}
	
	public void deleteList(ListTask list) {
		listsdatasource.deleteListTask(list);
		adapter.remove(list);
		updatedData();
	}
	
	public void renameList(int position, String newName) {
		ListTask listTask = adapter.getItem(position);
		listsdatasource.renameListTask(listTask, newName);
		updatedData();
	}

	public void updatedData() {
	    adapter.clear(); 
	    List<ListTask> values = listsdatasource.getAllLists();
	    if (values != null){
	        for (ListTask list : values) {
	            adapter.insert(list, adapter.getCount());
	        }
	    }
	    adapter.notifyDataSetChanged();
	}


	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
	    ContextMenuInfo menuInfo) {
		
	    AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)menuInfo;
	    contextList =info.position;
	    
	    String[] menuItems = getResources().getStringArray(R.array.ContextMenuItems);
	    for (int i = 0; i<menuItems.length; i++) {
	      menu.add(Menu.NONE, i, i, menuItems[i]);
	    }
	
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
	  AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
	  int menuItemIndex = item.getItemId();
	  
	  if (menuItemIndex == 0) {
		  //delete
		  deleteList(contextList);
	  }
	  else if (menuItemIndex == 1) {
		// 1. Instantiate an AlertDialog.Builder with its constructor
		  AlertDialog.Builder builder = new AlertDialog.Builder(this);
		  LayoutInflater inflater = this.getLayoutInflater();
		  // 2. Chain together various setter methods to set the dialog characteristics
		  View inflator = inflater.inflate(R.layout.rename_dialog, null);
		  builder.setView(inflator);
		  final EditText renameEdit = (EditText) inflator.findViewById(R.id.renameEdit);
		  renameEdit.setText(adapter.getItem(contextList).getName());
	
		  builder.setPositiveButton(R.string.renameBtnOK, new DialogInterface.OnClickListener() {
	          @Override
	          public void onClick(DialogInterface dialog, int id) {
	    	  	String newName = renameEdit.getText().toString();
	    	  	renameList(contextList,newName);
	          }
	      })
	      .setNegativeButton(R.string.renameBtnCancel, new DialogInterface.OnClickListener() {
	          public void onClick(DialogInterface dialog, int id) {
	              
	          }
	      });
		  
		  // 3. Get the AlertDialog from create()
		  AlertDialog dialog = builder.create();
		  dialog.show();
		  //ListContainer.ListLists.get(position).rename();
	  }
	  
	  return false;
	}

	@Override
	protected void onResume() {
	  listsdatasource.open();
	  super.onResume();
	}
	
	@Override
	protected void onPause() {
	  listsdatasource.close();
	  super.onPause();
	}
	
	public class ListTaskAdapter extends ArrayAdapter<ListTask>{
	
	    Context context;
	    int layoutResourceId;   
	    List<ListTask> data;
	   
	    public ListTaskAdapter(Context context, int layoutResourceId, List<ListTask> data) {
	        super(context, layoutResourceId, data);
	        this.layoutResourceId = layoutResourceId;
	        this.context = context;
	        this.data = data;
	    }
	
	    @Override
	    public View getView(int position, View convertView, ViewGroup parent) {
	        View row = convertView;
	        ListTaskHolder holder = null;
	       
	        if(row == null)
	        {
	            LayoutInflater inflater = ((Activity)context).getLayoutInflater();
	            row = inflater.inflate(layoutResourceId, parent, false);
	           
	            holder = new ListTaskHolder();
	            holder.txtTitle = (TextView)row.findViewById(R.id.textViewListTask);
	           
	            row.setTag(holder);
	        }
	        else
	        {
	            holder = (ListTaskHolder)row.getTag();
	        }
	       
	        ListTask list = data.get(position);
	        holder.txtTitle.setText(list.toString());
	        long num = listsdatasource.getNumberTaskUnchecked(list.getId());
	        if (num == 0) {
	        	 holder.txtTitle.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.bullets_list_icon), null, null, null);
	        }
	        else {
	        	BitmapDrawable bitmapDraw = writeOnDrawable(Long.toString(num));
	        	holder.txtTitle.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.bullets_list_icon), null, bitmapDraw, null);
	        }
	        
	        
	       
	        return row;
	    }
	   
	    public class ListTaskHolder
	    {
	        TextView txtTitle;
	    }
	}
	
	public BitmapDrawable writeOnDrawable(String text){
	
	    Bitmap bm = Bitmap.createBitmap(100, 60, Bitmap.Config.ARGB_8888);
	
	    Paint paint = new Paint(); 
	    paint.setStyle(Style.FILL);  
	    paint.setColor(Color.BLACK);
	    paint.setTextSize(60); 
	
	    Canvas canvas = new Canvas(bm);
	    canvas.drawText(text, 0, 45, paint);
	
	    return new BitmapDrawable(bm);
	}
}
