package com.example.caterpillar_scheduler;

import java.util.List;

import com.example.caterpillar_scheduler.TaskListActivity.ListTaskAdapter;
import com.example.caterpillar_scheduler.TaskListActivity.ListTaskAdapter.ListTaskHolder;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.NavUtils;
import android.support.v4.widget.CursorAdapter;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;


/**
 * An activity representing a single Task detail screen. This activity is only
 * used on handset devices. On tablet-size devices, item details are presented
 * side-by-side with a list of items in a {@link TaskListActivity}.
 * <p>
 * This activity is mostly just a 'shell' activity containing nothing more than
 * a {@link TaskDetailFragment}.
 */
public class TaskDetailActivity extends Activity {
	public static int contextTask;
	
	public static String LIST_ID = "list_id";
	public static String LIST_NAME = "list_name";
	public static long list_id;
	public static String list_name;
	public static long CHECK_FALSE = 0;
	public static long CHECK_TRUE = 1;
	
	public static long defaultID = 0;
	
	public TasksDataSource tasksdatasource;
	public TaskAdapter adapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_task_detail);
		
		Intent dIntent = getIntent();
		list_id = dIntent.getLongExtra(LIST_ID, defaultID);
		list_name = dIntent.getStringExtra(LIST_NAME);
		
		tasksdatasource = new TasksDataSource(this);
		tasksdatasource.open();
		setTitle(list_name);
		
		List<Task> values = tasksdatasource.getAllTasks(list_id);
		
		adapter = new TaskAdapter(this, R.layout.taskview, values);
		/*
		adapter = new ArrayAdapter<Task>(this,
				android.R.layout.simple_list_item_checked,
				values);*/
		ListView list = (ListView)findViewById(R.id.task_task_list);
		list.setAdapter(adapter);
		list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
		
		for (int i=0; i < adapter.getCount(); i++) {
			Task task = adapter.getItem(i);
			long isChecked = task.getChecked();
			if (isChecked == CHECK_TRUE) {
				list.setItemChecked(i, true);
			}
			else {
				list.setItemChecked(i, false);
			}
		}
		
		list.setOnItemClickListener(new OnItemClickListener() {
	
			@Override
			public void onItemClick(AdapterView<?> adap, View v, int position,
					long id) {
				changeStateTask(position);	
			}
	
		});
		
		
		// Show the Up button in the action bar.
		getActionBar().setDisplayHomeAsUpEnabled(true);		
		
		final EditText edittext = (EditText) findViewById(R.id.taskEdit);
		edittext.setImeOptions(EditorInfo.IME_ACTION_DONE);
		edittext.setOnEditorActionListener(new TextView.OnEditorActionListener() {
	        @Override
	        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
	            if (actionId == EditorInfo.IME_ACTION_DONE) {
	            	
	            	addNewTask(v.getText().toString());
	            	v.setText("");
	            	//return true;
	            }
	            return false;
	        }
	    });
		
		registerForContextMenu(findViewById(R.id.task_task_list));
	}
	
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
	    ContextMenuInfo menuInfo) {

	    AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)menuInfo;
	    contextTask = info.position;
	    //String selectedWord = ((TextView) info.targetView).getText().toString();
	    //long selectedWordId = info.id;
	    //Toast.makeText(this, selectedWord, Toast.LENGTH_SHORT).show();
	    //menu.setHeaderTitle(selectedWord);
	    String[] menuItems = getResources().getStringArray(R.array.ContextMenuTasks);
	    for (int i = 0; i<menuItems.length; i++) {
	      menu.add(Menu.NONE, i, i, menuItems[i]);
	    }

	}
	
	@Override
	public boolean onContextItemSelected(MenuItem item) {
	  AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
	  int menuItemIndex = item.getItemId();
	  
	  if (menuItemIndex == 0) {
		  //delete
		  deleteTask(contextTask);
	  }
	  else if (menuItemIndex == 1) {
		  //rename
		  // 1. Instantiate an AlertDialog.Builder with its constructor
		  AlertDialog.Builder builder = new AlertDialog.Builder(this);
		  LayoutInflater inflater = this.getLayoutInflater();
		  // 2. Chain together various setter methods to set the dialog characteristics
		  View inflator = inflater.inflate(R.layout.rename_dialog, null);
		  builder.setView(inflator);
		  final EditText renameEditT = (EditText) inflator.findViewById(R.id.renameEdit);
		  renameEditT.setText(adapter.getItem(contextTask).getName());

		  builder.setPositiveButton(R.string.renameBtnOK, new DialogInterface.OnClickListener() {
	          @Override
	          public void onClick(DialogInterface dialog, int id) {
	    	  	String newName = renameEditT.getText().toString();
	    	  	renameTask(contextTask,newName);
	          }
	      })
	      .setNegativeButton(R.string.renameBtnCancel, new DialogInterface.OnClickListener() {
	          public void onClick(DialogInterface dialog, int id) {
	              
	          }
	      });
		  
		  // 3. Get the AlertDialog from create()
		  AlertDialog dialog = builder.create();
		  dialog.show();
	  }
	  
	  return false;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// This ID represents the Home or Up button. In the case of this
			// activity, the Up button is shown. Use NavUtils to allow users
			// to navigate up one level in the application structure. For
			// more details, see the Navigation pattern on Android Design:
			//
			// http://developer.android.com/design/patterns/navigation.html#up-vs-back
			//
			NavUtils.navigateUpTo(this,
					new Intent(this, TaskListActivity.class));
			return true;
		}
		return super.onOptionsItemSelected(item);
		
	}
	
	public void addNewTask(String name) {
		Task task = tasksdatasource.createTask(name,CHECK_FALSE,list_id);
		adapter.add(task);
		updatedData();
		/*
		TaskDetailFragment listItems = (TaskDetailFragment) getSupportFragmentManager().findFragmentById(R.id.task_task_list);
		listItems.addNewTaskItem(name);
		*/
	}
	
	public void deleteTask(int position) {
		Task task = adapter.getItem(position);
		tasksdatasource.deleteTask(task);
		adapter.remove(task);
		updatedData();
		/*
		TaskDetailFragment listItems = (TaskDetailFragment) getSupportFragmentManager().findFragmentById(R.id.task_task_list);
		listItems.deleteTaskItem(position);
		*/
	}
	
	public void renameTask(int position, String newName) {
		Task task = adapter.getItem(position);
		tasksdatasource.renameTask(task, newName);
		updatedData();
		//adapter.notifyDataSetChanged();
		/*
		TaskDetailFragment listItems = (TaskDetailFragment) getSupportFragmentManager().findFragmentById(R.id.task_task_list);
		listItems.renameTaskItem(position,newName);
		*/
	}
	
	public void changeStateTask(int position) {
		Task task = adapter.getItem(position);
		long newState = CHECK_FALSE;
		if(!task.isChecked()) {
			newState = CHECK_TRUE;
		}
		tasksdatasource.setCheckStateTask(task,newState);
		updatedData();
	}
	
	public void updatedData() {
	    adapter.clear(); 
	    List<Task> values = tasksdatasource.getAllTasks(list_id);
	    if (values != null){
	        for (Task task : values) {
	            adapter.insert(task, adapter.getCount());
	        }
	    }
	    adapter.notifyDataSetChanged();
	}
	
	@Override
	protected void onResume() {
	  tasksdatasource.open();
	  super.onResume();
	}

	@Override
	protected void onPause() {
	  tasksdatasource.close();
	  super.onPause();
	}
	
	public class TaskAdapter extends ArrayAdapter<Task>{
		
	    Context context;
	    int layoutResourceId;   
	    List<Task> data;
	   
	    public TaskAdapter(Context context, int layoutResourceId, List<Task> data) {
	        super(context, layoutResourceId, data);
	        this.layoutResourceId = layoutResourceId;
	        this.context = context;
	        this.data = data;
	    }
	
	    @Override
	    public View getView(int position, View convertView, ViewGroup parent) {
	        View row = convertView;
	        TaskHolder holder = null;
	       
	        if(row == null)
	        {
	            LayoutInflater inflater = ((Activity)context).getLayoutInflater();
	            row = inflater.inflate(layoutResourceId, parent, false);
	           
	            holder = new TaskHolder();
	            holder.txtTitle = (CheckedTextView)row.findViewById(R.id.taskCheckedTextView);
	           
	            row.setTag(holder);
	        }
	        else
	        {
	            holder = (TaskHolder)row.getTag();
	        }
	       
	        Task task = data.get(position);
	        holder.txtTitle.setText(task.toString());
	        holder.txtTitle.setChecked(task.isChecked());
	        return row;
	    }
	   
	    public class TaskHolder
	    {
	        CheckedTextView txtTitle;
	    }
	}
	
	
	
}
