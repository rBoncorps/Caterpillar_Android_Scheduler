package com.example.caterpillar_scheduler;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

public class ListsDataSource {

  // Database fields
  public SQLiteDatabase database;
  public MySQLLiteHelper dbHelper;
  public static long CHECK_FALSE = 0;
  public static long CHECK_TRUE = 1;
  
  private String[] allColumns = { MySQLLiteHelper.LIST_ID,
      MySQLLiteHelper.LIST_NAME };
  private String[] allColumnsTask = { MySQLLiteHelper.TASK_ID,
	      MySQLLiteHelper.TASK_NAME,
	      MySQLLiteHelper.TASK_ISCHECKED,
	      MySQLLiteHelper.TASK_LISTID};
  public Context cont;

  public ListsDataSource(Context context) {
	  cont = context;
    dbHelper = new MySQLLiteHelper(context);
  }

  public void open() throws SQLException {
    database = dbHelper.getWritableDatabase();
  }

  public void close() {
    dbHelper.close();
  }

  public ListTask createListTask(String listName) {
    ContentValues values = new ContentValues();
    values.put(MySQLLiteHelper.LIST_NAME, listName);
    long insertId = database.insert(MySQLLiteHelper.TABLE_LISTS, null,
        values);
    Cursor cursor = database.query(MySQLLiteHelper.TABLE_LISTS,
        allColumns, MySQLLiteHelper.LIST_ID + " = " + insertId, null,
        null, null, null);
    cursor.moveToFirst();
    ListTask newComment = cursorToListTask(cursor);
    cursor.close();
    return newComment;
  }
  
  public long getNumberTaskUnchecked(long id) {
	  long countTaskUnchecked = 0;

	  Cursor cursor = database.query(MySQLLiteHelper.TABLE_TASKS,
        allColumnsTask, MySQLLiteHelper.TASK_LISTID + " = " + id, null, null, null, null);

	    cursor.moveToFirst();
	    while (!cursor.isAfterLast()) {
	    	long isChecked = cursor.getLong(2);
	    	if (isChecked == CHECK_FALSE) {
	    		countTaskUnchecked++;
	    	}
	    	cursor.moveToNext();
	    }
		    // Make sure to close the cursor
		    cursor.close();
		    return countTaskUnchecked;
  }

  public void deleteListTask(ListTask listTask) {
    long id = listTask.getId();
    database.delete(MySQLLiteHelper.TABLE_LISTS, MySQLLiteHelper.LIST_ID
        + " = " + id, null);
  }
  
  public List<ListTask> getAllDone() {
	  List<ListTask> llistTask = getAllLists();
	  List<ListTask> returnList = new ArrayList<ListTask>();
	  for(int i =0; i < llistTask.size(); i++) {
		  ListTask t = llistTask.get(i);
		  long num = getNumberTaskUnchecked(t.getId());
		  if(num == 0) {
			  returnList.add(t);
		  }
	  }
	  return returnList;
  }
  
  public void renameListTask(ListTask listTask, String newName) {
	  ContentValues args = new ContentValues();
	  args.put(MySQLLiteHelper.LIST_NAME, newName);
	  long id = listTask.getId();
	  database.update(MySQLLiteHelper.TABLE_LISTS, args, MySQLLiteHelper.LIST_ID
		        + " = " + id,null);
  }

  public List<ListTask> getAllLists() {
    List<ListTask> listListTask = new ArrayList<ListTask>();

    Cursor cursor = database.query(MySQLLiteHelper.TABLE_LISTS,
        allColumns, null, null, null, null, null);

    cursor.moveToFirst();
    while (!cursor.isAfterLast()) {
      ListTask listTask = cursorToListTask(cursor);
      listListTask.add(listTask);
      cursor.moveToNext();
    }
    // Make sure to close the cursor
    cursor.close();
    return listListTask;
  }

  private ListTask cursorToListTask(Cursor cursor) {
    ListTask listTask = new ListTask();
    listTask.setId(cursor.getLong(0));
    listTask.setName(cursor.getString(1));
    return listTask;
  }
} 