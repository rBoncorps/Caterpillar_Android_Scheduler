package com.example.caterpillar_scheduler;

public class Task {
	
	public long taskID;
	public String taskName;
	public long isChecked;
	public long task_listID;
	
	public long getId() {
		return taskID;
	}
	
	public void setId(long id) {
	    this.taskID = id;
	}
	
	public String getName() {
		return taskName;
	}
	
	public void setName(String newName) {
	    this.taskName = newName;
	}
	
	public void setChecked(long check) {
		this.isChecked = check;
	}
	
	public long getChecked() {
		return isChecked;
	}
	
	public void setTaskListID(long listID) {
		this.task_listID = listID;
	}
	
	public long getTaskListID() {
		return task_listID;
	}
	
	  // Will be used by the ArrayAdapter in the ListView
	  @Override
	  public String toString() {
	    return taskName;
	  }
	
	public boolean  isChecked() {
		if (isChecked == 0) {
			return false;
		}
		else {
			return true;
		}
	}

	
}
